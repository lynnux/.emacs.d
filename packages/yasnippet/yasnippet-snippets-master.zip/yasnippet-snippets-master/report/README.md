# Report snippets
