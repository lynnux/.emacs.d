.. Smartparens documentation master file, created by
   sphinx-quickstart on Sat Sep 10 22:33:55 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Smartparens's documentation!
=======================================

Contents:

.. toctree::
   :maxdepth: 2

   automatic-escaping


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
