# dev

Bunch of development notes and proposals.  Mostly of interest to the author and people involved with the project, but also to describe and review future API changes.
