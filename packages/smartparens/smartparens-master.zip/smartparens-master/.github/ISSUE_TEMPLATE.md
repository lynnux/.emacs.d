## Expected behavior



## Actual behavior



## Steps to reproduce the problem



## Backtraces if necessary (`M-x toggle-debug-on-error`)



## Environment & version information

- `smartparens` version:
- Active major-mode:
- Emacs version (`M-x emacs-version`):
- OS:
