See the [homepage](http://company-mode.github.com/).

[![Build Status](https://travis-ci.org/company-mode/company-mode.png?branch=master)](https://travis-ci.org/company-mode/company-mode)
[![MELPA](https://melpa.org/packages/company-badge.svg)](https://melpa.org/#/company)
